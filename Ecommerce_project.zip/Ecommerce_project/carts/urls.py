from django.urls import path
from . import views

urlpatterns = [
    path('', views.view_cart, name='view_cart'),
    path('add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('remove/<int:cart_item_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('payment_complete/', views.payment_complete, name='payment_complete'),
    path('purchase_complete/<str:payment_method>/', views.payment_complete, name='purchase_complete'),
    path('verify_payment/', views.verify_payment, name='verify_payment'),
]
