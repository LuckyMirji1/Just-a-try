from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Cart
from products.models import Product
import razorpay
from django.conf import settings
import json
from django.http import JsonResponse

client = razorpay.Client(auth=(settings.RAZORPAY_KEY_ID, settings.RAZORPAY_KEY_SECRET))

def view_cart(request):
    # Get all cart items for the logged-in user
    cart_items = Cart.objects.filter(user=request.user)

    # If no items in the cart, show a message
    if not cart_items:
        messages.info(request, "Your cart is empty.")

    # Calculate total price
    total_price = sum(item.total_price() for item in cart_items)

    return render(request, 'carts/cart.html', {'cart_items': cart_items, 'total_price': total_price})

def add_to_cart(request, product_id):
    # Get the product from the database
    product = Product.objects.get(id=product_id)

    # Get or create a cart item for the logged-in user and the selected product
    cart_item, created = Cart.objects.get_or_create(user=request.user, product=product)

    # If the item already exists in the cart, increment the quantity
    if not created:
        cart_item.quantity += 1
        cart_item.save()

    # Redirect to the cart page
    messages.success(request, f"Added {product.name} to your cart.")
    return redirect('view_cart')

def remove_from_cart(request, cart_item_id):
    # Get the cart item to be removed
    cart_item = Cart.objects.get(id=cart_item_id)

    # Delete the cart item
    cart_item.delete()

    # Show a success message and redirect to the cart page
    messages.success(request, "Item removed from your cart.")
    return redirect('view_cart')

def checkout(request):
    # Get all cart items for the logged-in user
    cart_items = Cart.objects.filter(user=request.user)

    # If cart is empty, redirect to cart page
    if not cart_items:
        messages.warning(request, "Your cart is empty. Please add items to the cart.")
        return redirect('view_cart')

    # Calculate the total price for all cart items
    total_price = sum(item.total_price() for item in cart_items)

    # If the method is POST, process checkout
    if request.method == 'POST':
        # Get the selected payment method (Razorpay or COD)
        payment_method = request.POST.get('payment_method')

        if payment_method == 'razorpay':
            try:
                # Create Razorpay order for payment
                order_amount = total_price * 100  # Convert price to paise (Razorpay expects paise)
                order_currency = 'INR'
                order = client.order.create(dict(
                    amount=order_amount,
                    currency=order_currency,
                    payment_capture='1'  # Auto capture payment
                ))

                # Get the Razorpay order ID
                order_id = order['id']
                context = {
                    'order_id': order_id,
                    'total_price': total_price,
                    'payment_method': payment_method,
                    'razorpay_key_id': settings.RAZORPAY_KEY_ID  # Pass the Razorpay key ID to the frontend
                }

                # Render the payment page for Razorpay
                return render(request, 'carts/payment.html', context)

            except Exception as e:
                # If there's an error with the Razorpay API
                messages.error(request, f"Error processing Razorpay payment: {str(e)}")
                return redirect('view_cart')

        elif payment_method == 'cod':
            # For COD, directly mark the purchase as complete
            cart_items.delete()  # Empty the cart
            messages.success(request, "Your order has been placed successfully. Please pay on delivery.")
            return redirect('purchase_complete', payment_method='COD')

    return render(request, 'carts/checkout.html', {'cart_items': cart_items, 'total_price': total_price})

def payment_complete(request, payment_method):
    # Empty the cart once the payment is complete
    Cart.objects.filter(user=request.user).delete()

    # Show a success message based on the payment method
    if payment_method == 'Razorpay':
        messages.success(request, "Your payment was successful. Thank you for your purchase!")
    else:
        messages.success(request, "Your order has been placed successfully. Please pay on delivery.")

    return render(request, 'carts/purchase_complete.html', {'payment_method': payment_method})

def verify_payment(request):
    if request.method == 'POST':
        # Parse the payment response from Razorpay
        payment_response = request.body.decode('utf-8')
        payment_data = json.loads(payment_response)

        razorpay_payment_id = payment_data['razorpay_payment_id']
        razorpay_order_id = payment_data['razorpay_order_id']
        razorpay_signature = payment_data['razorpay_signature']

        # Verify the payment with Razorpay using their checksum verification
        params_dict = {
            'razorpay_order_id': razorpay_order_id,
            'razorpay_payment_id': razorpay_payment_id,
            'razorpay_signature': razorpay_signature,
        }

        try:
            # Generate the checksum from Razorpay's secret key
            generated_signature = client.utility.verify_payment_signature(params_dict)

            if generated_signature == razorpay_signature:
                # If the signatures match, the payment is valid
                Cart.objects.filter(user=request.user).delete()  # Empty the cart after successful payment
                messages.success(request, "Your order has been placed successfully!")
                return JsonResponse({'success': True})

            else:
                # If the signatures do not match, the payment failed
                messages.error(request, "Payment verification failed!")
                return JsonResponse({'success': False})

        except Exception as e:
            messages.error(request, f"Error during payment verification: {str(e)}")
            return JsonResponse({'success': False})

    return JsonResponse({'success': False})

def purchase_complete(request, payment_method):
    # Get all cart items for the logged-in user
    cart_items = Cart.objects.filter(user=request.user)

    # Calculate total price for the cart items
    total_price = sum(item.total_price() for item in cart_items)

    # Empty the cart after purchase
    Cart.objects.filter(user=request.user).delete()

    # Render the purchase complete page with payment method and total price
    return render(request, 'carts/purchase_complete.html', {
        'payment_method': payment_method,
        'total_price': total_price,
        'cart_items': cart_items
    })
